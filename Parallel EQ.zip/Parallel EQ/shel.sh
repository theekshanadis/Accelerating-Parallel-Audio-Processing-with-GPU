#!/bin/bash

#used to create audioin.txt eqin.txt  files

for x in {1200..1400..1}
 do

 cp audioin0.txt  audioin$x.txt
 cp equalizer0.txt  equalizer$x.txt
 done







