#!/bin/bash

#compile the code
nvcc cufftMany.cu  helpers.cu -o cft -lcufft -arch=sm_20

#generate time for execution
for x in {5..100..10}
do
   ./cft $x >> a.out  
done  
