clc;

%read the audio file
[y Fs]=audioread('wave.wav');


%seconds
smpl_cnt=int32(length(y)/Fs);
%change sample count ( smpl_cnt == how much time (s) ) 
smpl_cnt=9;


%new signal
count=1;

%loop thr samples
for inc=1:Fs:Fs*smpl_cnt
    
    v=['0' '1' '2' '3' '4' '5' '6' '7' '8' '9'];
    file_name=['audioin' v(count) '.txt'];
    
    fprintf('Writing to : %s \n',file_name);
    count=count+1;
    
    %get the sample
    S=y(inc:inc+Fs-1);

    dlmwrite(file_name,S,'delimiter','\n','precision',4);
       
end
