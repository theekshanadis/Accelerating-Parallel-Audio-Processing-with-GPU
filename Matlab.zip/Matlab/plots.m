clc;

%read audioout1.txt to vector
A=textread('audioout1.txt','%f');

%plot the signal
subplot(1,2,1);
plot(A,'b');
title('CUDA Result');

grid on;

subplot(1,2,2);
plot(new,'r');
title('MATLAB Result');

grid on;