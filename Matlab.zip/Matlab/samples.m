%read the audio file
[y Fs]=audioread('wave.wav');

%equalizer
eq_str=[0 0 0 0 4 8 4 0 0 0];

%seconds
smpl_cnt=int32(length(y)/Fs);
%change sample count ( smpl_cnt == how much time (s) ) 
smpl_cnt=1;


%new signal
new=[];

%loop thr samples
for inc=1:Fs:Fs*smpl_cnt
        
    %get the sample
    S=y(inc:inc+Fs-1); 
    
    subplot(2,2,1);
    plot(S,'r');
    grid on;
    title('Original Sample');
    xlabel('Sample number');
    ylabel('Value(float)');
    
    tic;
    
    %FFT()
    Sf=fft(S);
    
    
    subplot(2,2,3);
    plot(real(Sf),'k');
    grid on;
    title('Sample in fequency domain(Symmetric signal)');
    xlabel('Frequency');
    ylabel('Strength');
    
    
    
    %EQ
    data_size=int32(length(S)/2);
    eq_size=int32(data_size/10);

    %equalize function
    for x=1:data_size-1
         Sf(x)=Sf(x)*eq_str((idivide((x-1),eq_size) +1)); 
         Sf(x+data_size)=Sf(x+data_size)*eq_str(10-idivide((x-1),eq_size));
    end
        
    subplot(2,2,4);
    plot(real(Sf),'c');
    grid on;
    title('After Equalization(Symmetric signal)')
    xlabel('Frequency');
    ylabel('Strength');
    
    %IFFT
    Sif=ifft(Sf);
    
    toc;
    
    subplot(2,2,2);
    plot(real(Sif),'g');
    grid on;
    title('Result');
    xlabel('Sample number');
    ylabel('Value(float)');
    
    %append to stream
    new=[new , real(Sif) ]; 
    
end

%to a wav file
audiowrite('eqresult_MATLAB.wav',new,Fs);



